#include "STC15F2K60S2.h"
//#include "ds1302.h"
#include "iic.h"
//#include "onewire.h"
#include "intrins.h"
typedef unsigned char u8;
typedef unsigned int u16;

/***********************��ʱ����*******************************/
void Delay100ms()		//@11.0592MHz
{
	unsigned char i, j, k;

	_nop_();
	_nop_();
	i = 5;
	j = 52;
	k = 195;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}


/***********************�����*******************************/
u8 code smg_du[] = {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F,0x77,0x7C,0x39,0x5E,0x79,0x71, 0x00};
u8 code smg_wei[] = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};


/*************************�������***********************************/ 
#define KEY P3
#define NO_KEY    0xff
#define KEY_STATE0 0
#define KEY_STATE1 1
#define KEY_STATE2 2
unsigned char key_scan()
{
	static unsigned char key_state = KEY_STATE0;	// ��̬����������ÿ�ΰ���״̬�ı��� 
	u8 key_value = 0, key_temp;						// key_val:���صļ�ֵ��key_temp:��ȡ��IO״̬
	u8 key1, key2;
	
	P30=0; P31=0; P32=0; P33=0; P34=1; P35=1; P42=1; P44=1;
	if (P44==0) key1=0x70;		// 0111 0000
	if (P42==0) key1=0xb0;		// 1011 0000
	if (P35==0) key1=0xd0;		// 1101 0000
	if (P34==0) key1=0xe0;		// 1110 0000
	if ((P44==1)&&(P42==1)&&(P35==1)&&(P34==1)) key1 = 0xf0;
	
	P30=1; P31=1; P32=1; P33=1; P34=0; P35=0; P42=0; P44=0;
	if (P33==0) key2=0x07;		// 0000 0111
	if (P32==0) key2=0x0b;		// 0000 1011
	if (P31==0) key2=0x0d;		// 0000 1101
	if (P30==0) key2=0x0e;		// 0000 1110
	if ((P33==1)&&(P32==1)&&(P31==1)&&(P30==1)) key2 = 0x0f;
	
	key_temp = key1 | key2;
	
	switch(key_state)
	{
		case KEY_STATE0:
			if(key_temp != NO_KEY)
			{
				key_state = KEY_STATE1;
			}
			break;
			
		case KEY_STATE1:
			if(key_temp==NO_KEY)
			{
				key_state = KEY_STATE0;
			}
			else
			{
				switch(key_temp)
				{
					case 0x77:key_value = 4; break; // 0111 0111
					case 0x7b:key_value = 5; break; // 0111 1011
					case 0x7d:key_value = 6; break; // 0111 1101
					case 0x7e:key_value = 7; break; // 0111 1110
					
					case 0xb7:key_value = 8; break; // 1011 0111
					case 0xbb:key_value = 9; break; // 1011 0111
					case 0xbd:key_value = 10; break; // 1011 0111
					case 0xbe:key_value = 11; break; // 1011 0111
					
					case 0xd7:key_value = 12; break; // 0111 0111
					case 0xdb:key_value = 13; break; // 0111 0111
					case 0xdd:key_value = 14; break; // 0111 0111
					case 0xde:key_value = 15; break; // 0111 0111
					
					case 0xe7:key_value = 16; break; // 0111 0111
					case 0xeb:key_value = 17; break; // 0111 0111
					case 0xed:key_value = 18; break; // 0111 0111
					case 0xee:key_value = 19; break; // 0111 0111
				}
				key_state = KEY_STATE2;
			}
			break;
			
		case KEY_STATE2:
			if(key_temp == NO_KEY)
			{
				key_state = KEY_STATE0;
			}
			break;
	}
	return key_value;
 } 



/*************************��ʱ��***********************************/
void Timer0Init(void)		//1000΢��@11.0592MHz
{
	AUXR |= 0x80;		//��ʱ��ʱ��1Tģʽ
	TMOD &= 0xF0;		//���ö�ʱ��ģʽ
	TL0 = 0xCD;		//���ö�ʱ��ֵ
	TH0 = 0xD4;		//���ö�ʱ��ֵ
	TF0 = 0;		//���TF0��־
	TR0 = 1;		//��ʱ��0��ʼ��ʱ
	
	//  ����ʱ�� 
	ET0 = 1;		// �򿪶�ʱ��0�ж� 
	EA = 1; 		// �����ж� 
}


/*************************������***********************************/
bit key_flag;
bit water_flag;
u8 show[8], show_p[8];
u16 total=0;


void main(void)
{
	u8 key_val=NO_KEY;
	u16 price;
	
	P2=0xa0;P0=0x00;P2=0x00; 	//close buzzer and relay
	P2=0x80;P0=0xff;P2=0x00;  //close led
	
	show[0]=0x00; show[1]=smg_du[0]|0x80; show[2]=smg_du[5]; show[3]=smg_du[0];
	show[4]=smg_du[0]; show[5]=smg_du[0]|0x80; show[6]=smg_du[0]; show[7]=smg_du[0];
	
	show_p[0]=0x00; show_p[1]=smg_du[0]|0x80; show_p[2]=smg_du[5]; show_p[3]=smg_du[0];
	show_p[4]=smg_du[0]; show_p[5]=smg_du[0]|0x80; show_p[6]=smg_du[0]; show_p[7]=smg_du[0];
	
	Timer0Init();
	
	EA=0;
	if(read_adc(0x01) > 64)
	{
		P2=0x80;P0=~0x01;P2=0x00;
	}
	else
	{
		P2=0x80;P0=~0x00;P2=0x00;
	}
	EA=1;
	
	while(1)
	{
		show[7]=smg_du[total%10];
		show[6]=smg_du[(total/10)%10];
		show[5]=smg_du[(total/100)%10]|0x80;
		show[4]=smg_du[(total/1000)%10];
		

		price = total * 0.5;
		show_p[7]=smg_du[price%10];
		show_p[6]=smg_du[(price/10)%10];
		show_p[5]=smg_du[(price/100)%10]|0x80;
		show_p[4]=smg_du[(price/1000)%10];

		
		// key_board 
		if (key_flag)
		{
			key_flag = 0;
			key_val = key_scan();
			switch(key_val)
			{
				case 4: break;
				case 5: break;
				
				case 6: 
					P2=0xa0;P0=0;P2=0x00;
					water_flag = 0;
				break;
				
				case 7: 
					P2=0xa0;P04=1;P2=0x00;
					if(water_flag==0)
					{
						water_flag = 1;
						total = 0;
					}
				break;			
			}
			if(total >= 9999) {
				water_flag = 0;
				P2=0xa0;P0=0x00;P2=0x00;
			}
		}
	}
}



/*************************�жϷ�����***********************************/

void timer0() interrupt 1 using 1
{
	static int key_count=0,smg_count=0,i=0, water_count=0;
	key_count++;smg_count++;water_count++;
	
	if(key_count == 10)
	{
		key_count=0;
		key_flag = 1;
	}
	
	if(smg_count == 3)
	{
		smg_count=0;
		P2=0xc0;P0=0;P2=0;				//��Ӱ
		
		if(water_flag){
			P2=0xe0;P0=~show[i];P2=0;
		}else{
			P2=0xe0;P0=~show_p[i];P2=0;
		}
		
		P2=0xc0;P0=smg_wei[i];P2=0;
		i++;
		if(i==8) i=0;
	}
	if(water_count == 1000)
	{
		water_count = 0;
		if(water_flag)
		{
			total += 10;
		}
	}
}



