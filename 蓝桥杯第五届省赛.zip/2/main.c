#include "STC15F2K60S2.h"
#include "ds1302.h"
#include "iic.h"
//#include "onewire.h"
#include "intrins.h"
typedef unsigned char u8;
typedef unsigned int u16;

/***********************��ʱ����*******************************/
void Delay100ms()		//@11.0592MHz
{
	unsigned char i, j, k;

	_nop_();
	_nop_();
	i = 5;
	j = 52;
	k = 195;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}


/***********************�����*******************************/
u8 code smg_du[] = {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F,0x00};
u8 code smg_wei[] = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};


/*************************�������***********************************/ 
#define KEY P3
#define NO_KEY    0xff
#define KEY_STATE0 0
#define KEY_STATE1 1
#define KEY_STATE2 2
unsigned char key_scan()
{
	static unsigned char key_state = KEY_STATE0;	// ��̬����������ÿ�ΰ���״̬�ı��� 
	u8 key_value = 0, key_temp;						// key_val:���صļ�ֵ��key_temp:��ȡ��IO״̬
	u8 key1, key2;
	
	P30=0; P31=0; P32=0; P33=0; P34=1; P35=1; P42=1; P44=1;
	if (P44==0) key1=0x70;		// 0111 0000
	if (P42==0) key1=0xb0;		// 1011 0000
	if (P35==0) key1=0xd0;		// 1101 0000
	if (P34==0) key1=0xe0;		// 1110 0000
	if ((P44==1)&&(P42==1)&&(P35==1)&&(P34==1)) key1 = 0xf0;
	
	P30=1; P31=1; P32=1; P33=1; P34=0; P35=0; P42=0; P44=0;
	if (P33==0) key2=0x07;		// 0000 0111
	if (P32==0) key2=0x0b;		// 0000 1011
	if (P31==0) key2=0x0d;		// 0000 1101
	if (P30==0) key2=0x0e;		// 0000 1110
	if ((P33==1)&&(P32==1)&&(P31==1)&&(P30==1)) key2 = 0x0f;
	
	key_temp = key1 | key2;
	
	switch(key_state)
	{
		case KEY_STATE0:
			if(key_temp != NO_KEY)
			{
				key_state = KEY_STATE1;
			}
			break;
			
		case KEY_STATE1:
			if(key_temp==NO_KEY)
			{
				key_state = KEY_STATE0;
			}
			else
			{
				switch(key_temp)
				{
					case 0x77:key_value = 4; break; // 0111 0111
					case 0x7b:key_value = 5; break; // 0111 1011
					case 0x7d:key_value = 6; break; // 0111 1101
					case 0x7e:key_value = 7; break; // 0111 1110
					
					case 0xb7:key_value = 8; break; // 1011 0111
					case 0xbb:key_value = 9; break; // 1011 0111
					case 0xbd:key_value = 10; break; // 1011 0111
					case 0xbe:key_value = 11; break; // 1011 0111
					
					case 0xd7:key_value = 12; break; // 0111 0111
					case 0xdb:key_value = 13; break; // 0111 0111
					case 0xdd:key_value = 14; break; // 0111 0111
					case 0xde:key_value = 15; break; // 0111 0111
					
					case 0xe7:key_value = 16; break; // 0111 0111
					case 0xeb:key_value = 17; break; // 0111 0111
					case 0xed:key_value = 18; break; // 0111 0111
					case 0xee:key_value = 19; break; // 0111 0111
				}
				key_state = KEY_STATE2;
			}
			break;
			
		case KEY_STATE2:
			if(key_temp == NO_KEY)
			{
				key_state = KEY_STATE0;
			}
			break;
	}
	return key_value;
 } 



/*************************��ʱ��***********************************/
void Timer0Init(void)		//1000΢��@11.0592MHz
{
	AUXR |= 0x80;		//��ʱ��ʱ��1Tģʽ
	TMOD &= 0xF0;		//���ö�ʱ��ģʽ
	TL0 = 0xCD;		//���ö�ʱ��ֵ
	TH0 = 0xD4;		//���ö�ʱ��ֵ
	TF0 = 0;		//���TF0��־
	TR0 = 1;		//��ʱ��0��ʼ��ʱ
	
	//  ����ʱ�� 
	ET0 = 1;		// �򿪶�ʱ��0�ж� 
	EA = 1; 		// �����ж� 
}


/*************************������***********************************/
bit key_flag;
bit mode;
bit buzzer_flag, relay_flag;
bit set_flag, set_buzzer;
u8 show[8],set_show[8];
u8 shi, fen, miao;
u8 humidity,humidity_th=50;
void main(void)
{
	u8 key_val=NO_KEY;
	u8 i=0;
	
	P2=0xa0;P0=0x00;P2=0x00; 	//close buzzer and relay
	P2=0x80;P0=0xff;P2=0x00;
	
	set_sfm(8,30,0);	
	humidity_th = read_24c02(0x55);
	Timer0Init();

	while(1)
	{
		EA=0;
		humidity=(u8)(read_adc(0x03)/2.57f);
		EA=1;
		
		shi = Read_Ds1302_Byte(0x85);
		fen = Read_Ds1302_Byte(0x83);
		miao = Read_Ds1302_Byte(0x81);
		
		show[0]=~smg_du[shi/16];
		show[1]=~smg_du[shi%16];
		show[2]=smg_du[0]|0x80; 	// -
		show[3]=~smg_du[fen/16];
		show[4]=~smg_du[fen%16];
		show[5]=~smg_du[10];       // _
		show[6]=~smg_du[humidity/10];
		show[7]=~smg_du[humidity%10];
		
		set_show[0]=smg_du[0]|0x80; 	// -
		set_show[1]=smg_du[0]|0x80; 	// -
		set_show[2]=~0x00;
		set_show[3]=~0x00;
		set_show[4]=~0x00;
		set_show[5]=~0x00;
		set_show[6]=~smg_du[humidity_th/10];
		set_show[7]=~smg_du[humidity_th%10];
		
		
		
		if(mode == 0)	// auto
		{
			P2=0x80;P0=~0x01;P2=0x00;
			if(humidity < humidity_th)		//	open	L1
			{
				relay_flag = 1;
			}
			else
			{
				relay_flag = 0;
			}
		}
		else
		{
			if(humidity < humidity_th)		//	open	buzzer
			{
				if(set_buzzer==0) 
				{
					buzzer_flag = 1;
				}
			}
			else
			{
				if(set_buzzer==0)
					buzzer_flag = 0;
			}
			P2=0x80;P0=~0x02;P2=0x00;
		}
		
		
		write_24c02(0x55,humidity_th);
		
		
		// operation in relay and buzzer
		if(buzzer_flag==0 && relay_flag==0) 
		{
			P2=0xa0;P04=0;P06=0;P2=0x00;
		}
		if(buzzer_flag==1 && relay_flag==0) 
		{
			P2=0xa0;P04=0;P06=1;P2=0x00;
		}
		if(buzzer_flag==0 && relay_flag==1) 
		{
			P2=0xa0;P04=1;P06=0;P2=0x00;
		}
		if(buzzer_flag==1 && relay_flag==1) 
		{
			P2=0xa0;P04=1;P06=1;P2=0x00;
		}
		
		
		// key_board 
		if (key_flag)
		{
			key_flag = 0;
			key_val = key_scan();
			switch(key_val)
			{
				case 4: 
					if(mode == 1)
					{
						relay_flag = 0;
					}
					else
					{
						humidity_th--;
					}
					break;
				case 5: 
					if(mode == 1)
					{
						relay_flag = 1;
					}
					else
					{
						humidity_th++;
					}
					break;
				case 6: 
					if(mode == 1)			// 1 - manual    0 - automatic
					{
//						set_buzzer = ~set_buzzer;
						set_buzzer = ~set_buzzer;
						if(set_buzzer==1) buzzer_flag = 0;
					}
					else
					{
						set_flag = ~set_flag;
					}
					break;
				case 7: mode = ~mode;break;			
			}
		}
	}
}



/*************************�жϷ�����***********************************/

void timer0() interrupt 1 using 1
{
	static int key_count=0,smg_count=0,i=0;
	key_count++;smg_count++;
	
	if(key_count == 10)
	{
		key_count=0;
		key_flag = 1;
	}
	
	if(smg_count == 3)
	{
		smg_count=0;
		P2=0xc0;P0=0;P2=0;				//��Ӱ
		if(set_flag)
		{
			P2=0xe0;P0=set_show[i];P2=0;
			P2=0xc0;P0=smg_wei[i];P2=0;
		}
		else
		{
			P2=0xe0;P0=show[i];P2=0;
			P2=0xc0;P0=smg_wei[i];P2=0;
		}
		i++;
		if(i==8) i=0;
	}
}



